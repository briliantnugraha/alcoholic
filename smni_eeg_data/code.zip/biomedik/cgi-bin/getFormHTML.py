#!/usr/bin/python

# Import modules for CGI handling 
import cgi,os
import cgitb
from classify import Preprocessing
from classify import Classification
from knn import KNN
cgitb.enable()

form = cgi.FieldStorage() 
print "Content-type: text/html\n"

print '''
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Biomedic</title>
    <link href="/css/bootstrap.css" rel="stylesheet">
    <link href="/css/second_css.css" rel="stylesheet">
  </head>
  <body>
    <h1 style='text-align:center'>This is used for Biomedical Computation Mid-Semester 2015</h1>
    <p style='text-align:center'>Demo by <a href="#">Brilian T. Nugraha</a></p>
    <form role='form' class='form-horizontal panel panel default' enctype="multipart/form-data" method='post'>
      <h2 style='text-align:center'>Testing</h2>
      <div class='form-group'>
        <div class='col-sm-6'>
          <label>Plot Number</label>
          <input type='text' placeholder='Fill the number of plot here(0-63)' name='plt' class = "form-control">
          <p class = "help-block">Example: 10</p>
          <input type='submit' class='btn btn-primary' name='seePlot' value='See plot'/>
        </div>

        <div class='col-sm-6'>
          <div class='col-sm-6'>
            <label>Predict Data</label>
            <input type='file' placeholder='Search file' name='sfile' class = "form-control">
            <p class = "help-block">D:/Biomedik/</p>
          </div>
          <div class='col-sm-6'>
            <label>Input Class</label>
            <input type='text' placeholder='Fill in here' name='nclass' class = "form-control">
            <p class = "help-block">Example: 10</p>
          </div>

          <div class='col-sm-12'>
            <label>Type of preprocessing</label>
            <input type='text' placeholder='Fill in here' name='typeClass' class = "form-control">
            <p class = "help-block">Example: (wavelet/average)</p>
          </div>
          <input class='col-sm-4 col-sm-offset-4 btn btn-primary' type='submit' name='searchFile' value='Search File'/>
        </div>
      </div><br/>


      <h2 style='text-align:center'>Preprocessing</h2>
      <DIV class='col-sm-12'>
        <label>Dataset Location</label>
        <input type='text' placeholder='Enter location' name='location' class = "form-control">
        <p class = "help-block">Example: D:/Biomedik/</p>
      </DIV>
      <div class='form-group' style='text-align:center'>
        <input type='submit' class='btn btn-primary' name='preprocessing'value='Execute Preprocessing'/>
      </div><br/>

      <h2 style='text-align:center'>Classification</h2>
      <DIV class='col-sm-6'>
        <label>Number of Tester</label>
        <input type='text' placeholder='Fill in here' name='ntester' class = "form-control">
        <p class = "help-block">Example: 10</p>
      </DIV>
      <div class='form-group col-sm-6' style='text-align:center'>
        <label>View two class (C/A)</label><input type='checkbox' value='on' name='two'><br/>
        <label>View three class (1/M/N)</label><input type='checkbox' value='on' name='three'><br/>
        <input type='submit' class='btn btn-primary' name='classification' value='Classify Data'/>
      </div><br/><br/><br/><br/><br/>
    </form>
    <script src="C:/Users/Brilian T. Nugraha/biomedik/js/bootstrap.min.js"></script>
'''

seePlot = None
ntester = None
location = None
two = None
three = None
seePlot = form.getvalue('plt')
ntester = form.getvalue('ntester')
location = form.getvalue('location')
two = form.getvalue('two')
three  = form.getvalue('three')
a = [None for i in range(2)]
if(location!=None and location!=''):
	if "preprocessing" in form:
                print '<div class="alert alert-success"><strong>Preprocessing done!</strong></div>'
                preprocess = Preprocessing()
                preprocess.getDirectory(str(location))
                preprocess.Preprocessing()
elif "classification" in form:
        classify = ''
        if ntester==None or ntester=='':
          ntester = int(20)
        if 'on'==str(two) or 'on'==str(three):
          classify = Classification()
          if 'on'==str(two): 
            print '<div class="alert alert-success"><strong>Classification (C/A) done!</strong></div>'
            classify.doClassify(0,int(ntester))
          if 'on'==str(three): 
            print '<div class="alert alert-success"><strong>Classification (1/M/N) done!</strong></div>'
            classify.doClassify(1,int(ntester))
        else :
          print '<div class="alert alert-warning"><strong>Classification option hasn\'t been made!</strong></div>'

elif "seePlot" in form:
  if seePlot:
    classify = Classification()
    classify.savePlot(int(seePlot))
    print '''<div class="row" style='margin-left:0'>
              <div class="col-md-6 panel panel-red"  >
                <h3 style='text-align:center' class='panel-heading'>Plot Real and Average Trial-'''+str(seePlot)+'''</h3>
                <img class='panel-body' height='400' width='675' src='../real_average.png'/></div>
              <div class="col-md-6 panel panel-red"  >
                <h3 style='text-align:center' class='panel-heading'>Plot Real and Wavelet Trial-'''+str(seePlot)+'''</h3>
                <img class='panel-body' height='400px' width='675' src='../real_wavelet.png'/></div>
            </div>
    '''
  else:
    print '<div class="alert alert-warning"><strong>Plot hasn\'t been chosed!</strong></div>'

elif "searchFile" in form:
  fileitem = form['sfile']
  nclass = form.getvalue('nclass') 
  typeClass = str(form.getvalue('typeClass'))
  if fileitem.filename and nclass!='' and typeClass!='':
     fn = os.path.basename(fileitem.filename)
     open(fn, 'wb+').write(fileitem.file.read())
     getFile=fileitem.file.read()
     getFile = getFile.split('\n')
     knn = KNN()
     knn.getData(fn)
     knn.openFIlePreprocessed(typeClass)
     knn.doKNN(typeClass,nclass)
     print '<div class="alert alert-success"><strong>The file has been successfully uploaded!</strong></div>'
  else:
     print '<div class="alert alert-warning"><strong>The option hasn\'t completely been filled!</strong></div>'

else:
  print '<div class="alert alert-danger"><strong>Input hasn\'t completely been filled!</strong></div>'


print '''
<script>
function showDiv(the) {
   if(document.getElementById(the).style.display=="block")document.getElementById(the).style.display = "none";
   else document.getElementById(the).style.display = "block";
}
</script>
  </body>
</html>
'''
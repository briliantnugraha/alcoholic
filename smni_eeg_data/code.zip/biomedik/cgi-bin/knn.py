import os
import math
import numpy as np

class KNN:
	def __init__(self):
		self.idx = []
		self.dataAsk = []
		self.total_data  = 60

	def getData(self,datas):
            f = open(datas)
            datas = f.read()
            datas = datas.split('\n')
            for data in datas[0:64]:
                data = data.split(',')
                data = map(float, data)
                data = np.array(data)
            	self.dataAsk.extend(data)
            self.dataAsk = self.dataAsk[0:len(self.dataAsk)]
            self.dataAsk = np.array(self.dataAsk)

	def openFIlePreprocessed(self,typeClass):
                self.FIlePreprocessed=[]
                folder = ''
                if typeClass=='wavelet':
                                folder = 'D:/Biomedik/wav/'
                else:
                        folder = 'D:/Biomedik/average/'	
                for i in range(self.total_data):
                    f = open(folder+str(i+1)+'.csv')
                    datas = f.read()
                    datas = datas.split('\n')
                    self.FIlePreprocessed.append([])
                    for data in datas[0:64]:
                        data = data.split(',')
                        data = map(float, data)
                        data = np.array(data)
                        self.FIlePreprocessed[i].extend(data)
                self.FIlePreprocessed = np.array(self.FIlePreprocessed)

        def predict(self,index,nclass):
                self.class_eeg = []
                f = open('D:/Biomedik/class/class_eeg.csv')
                datas = f.read()
                datas = datas.split('\n')
                for data in datas:
                    d = np.array(data.split(','))
                    d = [d[i] for i in index]
                    self.class_eeg.append(d)
                print '''
                <div class="col-sm-12">
                    <h3 style='text-align:center'>Predict Result</h3>
                    <table class="table table-striped">
                        <thead>
                          <tr>
                            <th>Value Predict Two Level(C/A)</th>
                            <th>Value Predict Three Level(I/M/N)</th>
                            <th>Predict Result Two Level(C/A)</th>
                            <th>Predict Result Three Level(I/M/N)</th>
                          </tr>
                        </thead>
                        <tbody>
                    '''
                m =[0 for i in range(2)]
                for iter in range(nclass):
                    m[0]+=int(self.class_eeg[0][iter])
                    m[1]+=int(self.class_eeg[1][iter])
                m[0] = float(float(m[0])/float(nclass))
                m[1] = float(float(m[1])/float(nclass))
                for iter in range(nclass):
                    print '''
                          <tr>
                            <td>'''+str(self.class_eeg[0][iter])+'''</td>
                            <td>'''+str(self.class_eeg[1][iter])+'''</td>
                            <td>'''
                    if(m[0]>1.5):
                        print 'Control'
                    elif(m[0]<=1.5):
                        print 'Alcoholic'
                    print '</td><td>'

                    if(m[1]<=1):
                        print '1'
                    elif(m[1]<=2 and m[1]>1):
                        print 'M'
                    elif(m[1]<=3 and m[1]>2):
                        print 'N'
                    print '</td></tr>'
                print '''
                        </tbody>
                      </table>
                    </div>
                '''

	def doKNN(self,typeClass,nclass):
                        nclass = int(nclass)
			self.neighbor = [0 for i in range(nclass)]
			for m in range(len(self.FIlePreprocessed)):
				mean = 0.0
				for z in range(len(self.FIlePreprocessed[m])):
					mean += pow(self.FIlePreprocessed[m][z] - self.dataAsk[z],2)
				sqrt_result = math.sqrt(float(mean))
				
				if m < nclass:
					self.neighbor[m]= sqrt_result
					self.idx.append(m)
				else:
					for j in range(nclass-1):
                                                for k in range(j+1,nclass):
                                                        if self.neighbor[j] > self.neighbor[k]:
                                                                temp = self.neighbor[j]
                                                                self.neighbor[j] = self.neighbor[k]	
                                                                self.neighbor[k] = temp	

                                                                temp = self.idx[j]
                                                                self.idx[j] = self.idx[k]	
                                                                self.idx[k] = temp 
					if(self.neighbor[nclass-1] > sqrt_result):
						self.neighbor[nclass-1] = sqrt_result
						self.idx[nclass-1] = m
			self.predict(self.idx, nclass)


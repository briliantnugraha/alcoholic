import os,numpy as np
import scipy as sp
import operator
from random import shuffle

from sklearn.svm import SVC
from sklearn.svm import LinearSVC
from sklearn.cross_validation import KFold
from sklearn.neighbors import KNeighborsClassifier

class Preprocessing:
    def __init__(self):
        self.total_data = 60
        self.nfile = 1
        self.data = ''
        self.batas = 157
        self.sdir='D:/Biomedik/average/'
        self.sdirRaw='D:/Biomedik/raw/'
        self.sdirWav='D:/Biomedik/wav/'

    def getDirectory(self,location):
        self.dat = str(location)
        self.fold = os.listdir(self.dat)

    def saveRealData(self,fold,nfile):
        avgFile = [[0 for a in range(256)] for b in range(64)]
        i=0
        counter = 0
        channel = 0
        while i < len(self.data):
            if channel>63:
                break
            if (counter<256) and i<len(self.data):
                avgFile[channel][counter] = self.data[i]
                i += 1
            else:
                channel += 1
                counter=-1
            counter += 1
        avgFile = np.array(avgFile)
        if os.path.isdir(self.sdirRaw)!= True:
            os.mkdir(self.sdirRaw)
        file = open(str(self.sdirRaw) +str(nfile)+'.csv','w')
        for i in range(len(avgFile)):        
            for j in range(len(avgFile[i])):
                file.write(str(avgFile[i][j]))
                if j < len(avgFile[i])-1:
                    file.write(',')
                else:
                    file.write('\n')
        file.close()
                            
    def saveMovingAverage(self,fold,nfile):
        mAverage = [[0 for a in range(self.batas)] for b in range(64)]
        i= 0
        counter = 0
        channel = 0
        total = 0
        while i < len(self.data):
            if channel>63:
                break
            if (counter+100<=256) and i+100<=len(self.data):
                total=0
                for j in range(i,100+i):
                    total += self.data[j]
                mAverage[channel][counter] = total/100
            else:
                i += 98
                channel += 1
                counter=-1
            counter += 1
            i += 1
        if os.path.isdir(self.sdir)!= True:
            os.mkdir(self.sdir)
        file = open(str(self.sdir) +str(nfile)+'.csv','w')
        for i in range(len(mAverage)):        
            for j in range(len(mAverage[i])):
                file.write(str(mAverage[i][j]))
                if j < len(mAverage[i])-1:
                    file.write(',')
                else:
                    file.write('\n')
        file.close()
                
    def getData(self,fopen):
        i=9
        counter = 1
        self.data = []
        while i<len(fopen):
            if counter<=256:
                self.data.append(float(fopen[i]))
            else:
                counter=0
            i +=4
            counter += 1

    def saveWavelet(self,fold,nfile):
        base = [128,64,32,16,8,4]
        m = [0,0,0,0,0,0]
        aproxFile = [[[0 for a in range(128)] for b in range(64)]for d in range(6)]
        detailFile = [[[0 for a in range(128)] for b in range(64)]for d in range(6)]
        lvl = 0
        channel = 0
        i = 0
        while lvl < 6:
            if channel > 63:
                m[lvl] = 1
                lvl += 1
                channel = 0
                continue
            if m[lvl]<base[lvl] and i<len(self.data) and lvl==0:
                aproxFile[lvl][channel][m[lvl]] = (self.data[i] + self.data[i+1])/2
                detailFile[lvl][channel][m[lvl]] = self.data[i] - aproxFile[lvl][channel][m[lvl]]
                m[lvl] += 1
                i += 2
            elif lvl>0 and m[lvl]<base[lvl]:
                aproxFile[lvl][channel][m[lvl]] = (aproxFile[lvl-1][channel][m[lvl-1]-1] + aproxFile[lvl-1][channel][m[lvl-1]])/2
                detailFile[lvl][channel][m[lvl]] = aproxFile[lvl-1][channel][m[lvl-1]-1] - aproxFile[lvl][channel][m[lvl]]
                m[lvl] += 1
                m[lvl-1] += 2
            else:
                m[lvl] = 0
                if lvl>0: 
                    m[lvl-1] = 1
                channel += 1
                
        all_File = []
        for cnl in range(64):
            all_File.append([])
            all_File[cnl].extend(aproxFile[5][cnl][0:4])
            all_File[cnl].extend(detailFile[5][cnl][0:4])
            all_File[cnl].extend(detailFile[4][cnl][0:8])
            all_File[cnl].extend(detailFile[3][cnl][0:16])
            all_File[cnl].extend(detailFile[2][cnl][0:32])
            #all_File[cnl].extend(detailFile[1][cnl][0:64])
            #all_File[cnl].extend(detailFile[0][cnl])
        if os.path.isdir(self.sdirWav)!= True:
            os.mkdir(self.sdirWav)
        file = open(str(self.sdirWav) +str(nfile)+'.csv','w')
        for i in range(len(all_File)):        
            for j in range(len(all_File[i])):
                file.write(str(all_File[i][j]))
                if j < len(all_File[i])-1:
                    file.write(',')
                else:
                    file.write('\n')
        file.close()
                
    def Preprocessing(self):
        nfile = 1
        if(self.fold):
            for z in range(len(self.fold)):
                if(os.path.isdir(self.dat+'/'+self.fold[z])):
                    f = os.listdir(self.dat+'/'+self.fold[z])
                    if(f):
                        for x in range(len(f)):
                            if(not f[x].endswith('.gz')):
                                c = ''
                                c = str(self.dat) + str('/') + str(self.fold[z]) + str('/') + str(f[x])
                                fop = open(c)
                                fopen = fop.read()
                                fopen = fopen.split(',')
                                fopen = fopen[3].split()
                                self.getData(fopen)
                                self.saveRealData(self.fold[z],nfile) #save real data
                                self.saveMovingAverage(self.fold[z],nfile) #save moving average result
                                self.saveWavelet(self.fold[z],nfile) #save wavelet result
                                nfile += 1


class Classification:
    def __init__(self):
        self.total_data = 60
        self.n_fitur = 1
        self.len_dataWav = 252
        self.len_dataMov = 157
        self.fold = 20
        self.forPlot = []

    def check_akurasi(self,Y1,Y2):
        total_benar = 0
        total_data = len(Y1)
        for i in range(total_data):
            if(Y1[i]==Y2[i]):total_benar+=1
        return float(float(total_benar)/float(total_data))

    def openFIlePreprocessed(self):
        self.X_wavelet=[]
        self.X_movingAverage=[]
        for i in range(self.total_data):
            f = open('D:/Biomedik/wav/'+str(i+1)+'.csv')
            datas = f.read()
            datas = datas.split('\n')
            self.X_wavelet.append([])
            for data in datas[0:64]:
                data = data.split(',')
                data = map(float, data[:len(data)-1])
                add_data = self.n_fitur-(self.len_dataWav%self.n_fitur)
                for j in range(add_data):
                    data.append(0.0)
                data = np.array(data)
                self.X_wavelet[i].extend(data)
        self.X_wavelet = np.array(self.X_wavelet)

        for i in range(self.total_data):
            f = open('D:/Biomedik/average/'+str(i+1)+'.csv')
            datas = f.read()
            datas = datas.split('\n')    
            self.X_movingAverage.append([])
            for data in datas[0:64]:
                data = data.split(',')
                data = map(float, data[:len(data)-1])
                add_data = self.n_fitur-(self.len_dataMov%self.n_fitur)
                for j in range(add_data):
                    data.append(0.0)
                data = np.array(data)
                self.X_movingAverage[i].extend(data)
        self.X_movingAverage = np.array(self.X_movingAverage)

    def openFileClass(self):
        self.class_eeg = []
        f = open('D:/Biomedik/class/class_eeg.csv')
        datas = f.read()
        Y = datas.split('\n')
        for data in Y:
            data = data.split(',')
            data = data[:self.total_data]
            data = np.array(data)
            self.class_eeg.append(data)

    def savePlot(self,opt=0):
        import matplotlib.pyplot as plt

        self.forPlot.append([])
        self.forPlot.append([])
        for i in range(self.total_data):
            f = open('D:/Biomedik/raw/'+str(i+1)+'.csv')
            datas = f.read()
            datas = datas.split('\n')
            data =datas[opt]
            data = data.split(',')
            data = map(float, data[:len(data)-1])
            data = np.array(data)
            self.forPlot[0].extend(data[0:156])
            self.forPlot[1].extend(data[0:63])
            f.close()
        
        self.forPlot.append([])
        for i in range(self.total_data):
            f2 = open('D:/Biomedik/average/'+str(i+1)+'.csv')
            datas2 = f2.read()
            datas2 = datas2.split('\n')
            data2 =datas2[opt]
            data2 = data2.split(',')
            data2 = map(float, data2[:len(data2)-1])
            data2 = np.array(data2)
            self.forPlot[2].extend(data2)
            f2.close()

        self.forPlot.append([])
        for i in range(self.total_data):
            f = open('D:/Biomedik/wav/'+str(i+1)+'.csv')
            datas = f.read()
            datas = datas.split('\n')
            data =datas[opt]
            data = data.split(',')
            data = map(float, data[:len(data)-1])
            data = np.array(data)
            self.forPlot[3].extend(data)
            f2.close()

        plt.plot(self.forPlot[0],'g')
        plt.plot(self.forPlot[2],'r')
        plt.savefig('real_average.png')
        plt.close()

        plt.plot(self.forPlot[1],'g')
        plt.plot(self.forPlot[3],'r')
        plt.savefig('real_wavelet.png')
        plt.close()
        
    
    def doClassify(self, option,ntester=20):
        self.openFileClass()
        self.openFIlePreprocessed()
        akurasi_mean = 0.0
        self.fold = ntester
        kf = KFold(self.total_data, n_folds=self.fold,shuffle=True)
        classifyWav = KNeighborsClassifier(n_neighbors=3)
        classifyMov = KNeighborsClassifier(n_neighbors=3)
        akurasi_wav = []
        akurasi_mov = []
        akurasi_mean_wav = 0.0
        akurasi_mean_mov = 0.0
        index = 0
        print '''<h3 class='panel-heading' style='text-align:center'>Classification using KNN</h3>'''
        print '<div class="row">'

        for ind,(train, test) in enumerate(kf):
            classifyWav.fit(self.X_wavelet[train],self.class_eeg[option][train])
            predWav = map(int,classifyWav.predict(self.X_wavelet[test]))
            realWav = map(int,self.class_eeg[option][test])
            akurasi_wav.append(self.check_akurasi(predWav,realWav))
            
            classifyMov.fit(self.X_movingAverage[train],self.class_eeg[option][train])
            predMov = map(int,classifyMov.predict(self.X_movingAverage[test]))
            realMov = map(int,self.class_eeg[option][test])
            akurasi_mov.append(self.check_akurasi(predMov,realMov))
            #print '<br/>THis is train: '+str(train)+' <br/>This is test:'+str(test)+'<br/><br/>'
            print '''

                <div class="col-sm-3 col-xs-6 panel panel-red" style='height:350px' >
                    <h3 class='panel-heading' style='text-align:center'>'''+str(ind+1)+'''</h3>
                    <dl style="width: 300px; background-color: lightgrey;">
                        <dt>'''+'WT-' +str(ind+1)+'''</dt>
                        <dd><div id="data-one" class="bar" style="width:'''+str(akurasi_wav[index]*100)+'''%">'''+str(akurasi_wav[index]*100)+'''%</div></dd>
                        <dt>'''+'MA-' +str(ind+1)+'''</dt>
                        <dd><div id="data-two" class="bar-green" style="width: '''+str(akurasi_mov[index]*100)+'''%">'''+str(akurasi_mov[index]*100)+'''%</div></dd>
                    </dl>

                    <input type="button" class='btn btn-success' name="answer" value="Detail" onclick="showDiv('welcomeDiv'''+str(ind+1)+'''')" />
                    <div id="welcomeDiv'''+str(ind+1)+'''"  style="display:none;" class="answer_list" >
                    <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>Wav Predict</th>
                        <th>MAverage Predict</th>
                        <th>Real Value</th>
                      </tr>
                    </thead>
                    <tbody>
                    '''
            for iter in range(3):
                print '''
                      <tr>
                        <td>'''+str(predWav[iter])+'''</td>
                        <td>'''+str(predMov[iter])+'''</td>
                        <td>'''+str(realMov[iter])+'''</td>
                      </tr>'''
            print '''
                    </tbody>
                  </table>
                    </div>
                </div>
            '''
            akurasi_mean_wav += akurasi_wav[index]
            akurasi_mean_mov += akurasi_mov[index]
            index += 1
        print '''
                <h3 class='panel-heading' style='text-align:center'>The mean accuracies are:</h3>
                <dl style="width: 300px" class='result'>
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            Mean Accuracy
                        </div>
                        <div class="panel-body">
                            <dt>'''+'WT-' +str('Wavelet')+'''</dt>
                            <dd><div id="data-one" class="bar" style="width:'''+str((akurasi_mean_wav/(float)(self.fold))*100)+'''%">
                            '''+str((akurasi_mean_wav/(float)(self.fold))*100)+'''%</div></dd>
                            <dt>'''+'MA-' +str('M_average')+'''</dt>
                            <dd><div id="data-two" class="bar-green" style="width: 
                            '''+str((akurasi_mean_mov/(float)(self.fold))*100)+'''%">
                            '''+str((akurasi_mean_mov/(float)(self.fold))*100)+'''%</div></dd>
                        </div>
                    </div>
                </dl>
                '''   

        print '''

        '''
